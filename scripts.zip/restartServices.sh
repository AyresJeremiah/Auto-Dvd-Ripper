sudo systemctl restart auto-rip-dvd
sudo systemctl restart dvd-transfer.service 
