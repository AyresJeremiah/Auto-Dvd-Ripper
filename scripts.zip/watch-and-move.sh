#!/bin/bash

WATCH_DIR="/home/jeremiah/dvd-rips"
DEST_DIR="/mnt/windows-share"
LOG_FILE="/var/log/dvd-transfer.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}

log "Starting DVD Watcher Service..."

# Function to process and move files
process_file() {
    local FILE="$1"
    local SRC_FILE="$WATCH_DIR/$FILE"
    local DEST_FILE="$DEST_DIR/$FILE"

    if [[ -f "$SRC_FILE" ]]; then
        log "Processing file: $FILE"

        log "Copying $SRC_FILE to $DEST_FILE..."
        cp "$SRC_FILE" "$DEST_FILE"

        if [ $? -eq 0 ]; then
            log "Successfully copied. Removing $SRC_FILE..."
            rm "$SRC_FILE"
        else
            log "Copy failed!"
        fi
    else
        log "File $SRC_FILE no longer exists, skipping..."
    fi
}

# 1. Process all existing .mp4 files at startup
log "Checking for existing files in $WATCH_DIR..."
while IFS= read -r -d '' FILE; do
    process_file "$(basename "$FILE")"
done < <(find "$WATCH_DIR" -maxdepth 1 -type f -name "*.mp4" -print0)

# 2. Monitor for new files and process them
while true; do
    inotifywait -q -e close_write,create,moved_to --format "%f" "$WATCH_DIR" | while read FILE; do
        process_file "$FILE"
    done
done

