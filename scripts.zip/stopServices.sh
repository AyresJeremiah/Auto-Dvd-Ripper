sudo systemctl stop auto-rip-dvd
sudo systemctl stop dvd-transfer.service 
