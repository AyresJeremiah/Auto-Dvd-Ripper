sudo systemctl start auto-rip-dvd
sudo systemctl start dvd-transfer.service 
