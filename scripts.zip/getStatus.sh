sudo systemctl status auto-rip-dvd
sudo systemctl status dvd-transfer.service 
