tail -f /var/log/dvd-transfer.log /var/log/dvd-rip.log 
